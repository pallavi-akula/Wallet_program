package com.capgemini.main;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.bean.Customer;
import com.capgemini.service.CustomerServiceImp;
import com.capgemini.service.ICustomerService;


public class Client {
	public static void main( String[] args )
	   {
		 CustomerServiceImp customerService;
			Map<String,Customer> data=new HashMap<String, Customer>();
		
			{
				System.out.println("Welcome to Payment Wallet Application");
				customerService=new CustomerServiceImp(data);
			}
			
		   
			String mobileNo;

			Customer customer ;

			BigDecimal bg=new BigDecimal("900.00");
			BigDecimal bg1=new BigDecimal("5000.00");
			BigDecimal bg2=new BigDecimal("700.00");
			BigDecimal bg3=new BigDecimal("500.00");
			BigDecimal bg4=new BigDecimal("400.00");
				        	Customer customer1=customerService.createAccount("pallavi","8885590001", bg);
				        	System.out.println("Account is created");
				        	Customer customer2=customerService.createAccount("priya","8885590002", bg1);
				        	System.out.println("Account is created");
				        	Customer customer3=customerService.createAccount("mahi","8885590003", bg2);
				        	System.out.println("Account is created");
				        	Customer customer4=customerService.createAccount("valli","8885590004", bg3);
				        	System.out.println("Account is created");
				        	Customer customer5=customerService.createAccount("krina","8885590005", bg4);
				        	System.out.println("Account is created");

//				  System.out.print("Enter the Mobile Number : ");
//					  mobileNo=console.next();
	//Customer  customer11=customerService.showBalance("8056342398");
	customer=customerService.showBalance("8885590001");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8885590002");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8885590003");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8885590004");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	customer=customerService.showBalance("8885590005");
	System.out.println("Your Current Balance is "+customer.getWallet().getBalance());
	   }
	}


