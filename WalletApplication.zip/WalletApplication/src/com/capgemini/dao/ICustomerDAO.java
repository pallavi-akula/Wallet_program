package com.capgemini.dao;

public interface ICustomerDAO {

}
